from flask import Flask, request, session, redirect, url_for, flash, render_template
import os
import hashlib
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(64)
flag = os.getenv('FLAG')
users = {}

data = [
    {
        'name': "Fête de la rentrée",
        'type': "Stand",
        'date': "Lundi 18 septembre 2024",
        'place': "Plaine de Nimy"
    },
    {
        'name': "Choisir son IDE",
        'type': "Workshop",
        'date': "Mercredi 25 septembre 2024 à 18h",
        'place': "Salle Turing (Grands Amphis)"
    },
    {
        'name': "Introduction à Linux",
        'type': "Workshop",
        'date': "Lundi 30 septembre 2024 à 18h",
        'place': "Salle Mirzakhani (De Vinci)"
    },
    {
        'name': "Introduction à la cybersécurité et aux CTF",
        'type': "Workshop & CTF",
        'date': "TBD",
        'place': "TBD"
    },
]

@app.route('/', methods=['GET'])
def home():
    global data
    if 'username' not in session:
        flash("Connectez vous pour accéder à cette page.")
        return redirect(url_for('login'))
    return render_template('home.html', data=data)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Hash the password with SHA-512
        hashed_password = hashlib.sha512(password.encode()).hexdigest()
        if username in users and users[username]['password'] == hashed_password:
            session['username'] = username
            session['role'] = users[username]['role']
            flash("Vous êtes connecté.")
            return redirect(url_for('home'))

        flash("Nom d'utilisateur ou mot de passe invalide.")
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form.get('role', 'user') # default to user if not set

        # Check if username or password is empty
        if not username or not password:
            flash("Nom d'utilisateur et mot de passe obligatoires.")
            return redirect(url_for('register'))

        # Hash the password with SHA-512
        hashed_password = hashlib.sha512(password.encode()).hexdigest()

        # Check if username is already taken 
        if username in users:
            flash("Ce nom d'utilisateur est déjà pris.")
            return redirect(url_for('register'))

        # Check if role exists
        if role not in ['admin', 'user']:
            flash("Role invalide.")
            return redirect(url_for('register'))

        users[username] = {
            'password': hashed_password,
            'role': role
        }
        flash("Votre compte a été créé.")
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/logout', methods=['GET'])
def logout():
    session.pop("username", None)
    session.pop("role", None)
    flash("Vous avez été déconnecté.")
    return redirect(url_for("home"))

@app.route('/admin', methods=['GET'])
def admin():
    global flag
    if "username" not in session or "role" not in session or session["role"] != "admin":
        flash("Vous n'avez pas la permission d'accéder à cette page.")
        return redirect(url_for("home"))

    return render_template("admin.html", flag=flag)


